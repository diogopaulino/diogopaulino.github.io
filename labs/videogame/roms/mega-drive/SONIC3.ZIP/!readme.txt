This file:  Sonic 3 & Knuckles, was made by:
D@' InN K33PeR. E-mail: da_inn_keeper@hotmail.com
Downloaded from: http://the-lair.net
If you found this file elsewhere, please
e-mail me where you got it from...

____________________________________________________

To play:

Just load sonic_k.1 into emulator (Genecyst v0.32 reccomended)