Hi! You've just downloaded a Rom from The RomZone! If 
you've downloaded it from else where, please e-mail me
at knuxsue@hotmail.com and tell me the url, so that I 
can deal with them.

Thanx, Sue (The RomZone Manager)